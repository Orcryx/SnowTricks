/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.7.2-MariaDB, for Linux (x86_64)
--
-- Host: web-lame.home    Database: SnowTricks
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

CREATE DATABASE IF NOT EXISTS `SnowTricks`;
USE `SnowTricks`;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_at` datetime NOT NULL,
  `update_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES
(1,'Grabs','2024-12-11 00:00:00','2024-12-11 00:00:00'),
(2,'Rotations','2024-12-11 00:00:00','2024-12-11 00:00:00'),
(3,'Flips','2024-12-11 00:00:00','2024-12-11 00:00:00'),
(4,'Jumps','2024-12-11 00:00:00','2024-12-11 00:00:00'),
(5,'Halfpipe / Slopestyle','2024-12-11 00:00:00','2024-12-11 00:00:00'),
(6,'Freeride / Backcountry','2024-12-11 00:00:00','2024-12-11 00:00:00'),
(7,'Manals / Wheelies','2024-12-11 00:00:00','2024-12-11 00:00:00');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `trick_id` int NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_at` datetime NOT NULL,
  `update_at` datetime NOT NULL,
  `user_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9474526CB281BE2E` (`trick_id`),
  KEY `IDX_9474526CA76ED395` (`user_id`),
  CONSTRAINT `FK_9474526CA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `FK_9474526CB281BE2E` FOREIGN KEY (`trick_id`) REFERENCES `trick` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES
(38,46,'Commentaire test du 05 mars 2025 a 13h47','2025-03-05 12:47:08','2025-03-05 12:47:08',16);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8mb3_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctrine_migration_versions`
--

LOCK TABLES `doctrine_migration_versions` WRITE;
/*!40000 ALTER TABLE `doctrine_migration_versions` DISABLE KEYS */;
INSERT INTO `doctrine_migration_versions` VALUES
('DoctrineMigrations\\Version20241211104926','2024-12-11 10:49:44',405),
('DoctrineMigrations\\Version20241211121952','2024-12-11 12:20:01',18),
('DoctrineMigrations\\Version20241218084129','2024-12-18 08:41:58',188),
('DoctrineMigrations\\Version20241218085706','2024-12-18 08:57:26',185),
('DoctrineMigrations\\Version20241218110454','2024-12-18 11:05:08',49),
('DoctrineMigrations\\Version20241218143239','2024-12-18 14:33:12',100),
('DoctrineMigrations\\Version20250107130023','2025-01-07 13:01:06',120),
('DoctrineMigrations\\Version20250115155714','2025-01-15 15:57:34',31),
('DoctrineMigrations\\Version20250212110047','2025-02-12 11:01:09',19),
('DoctrineMigrations\\Version20250212172737','2025-02-12 17:27:49',19),
('DoctrineMigrations\\Version20250218140242','2025-02-18 14:02:51',14),
('DoctrineMigrations\\Version20250218140402','2025-02-18 14:04:12',18),
('DoctrineMigrations\\Version20250218140459','2025-02-18 14:05:48',20),
('DoctrineMigrations\\Version20250224140226','2025-02-24 14:05:31',26),
('DoctrineMigrations\\Version20250305104451','2025-03-05 10:45:06',47);
/*!40000 ALTER TABLE `doctrine_migration_versions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messenger_messages`
--

DROP TABLE IF EXISTS `messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `messenger_messages` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `body` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `headers` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue_name` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `available_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `delivered_at` datetime DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`),
  KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
  KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
  KEY `IDX_75EA56E016BA31DB` (`delivered_at`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messenger_messages`
--

LOCK TABLES `messenger_messages` WRITE;
/*!40000 ALTER TABLE `messenger_messages` DISABLE KEYS */;
INSERT INTO `messenger_messages` VALUES
(28,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:6:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:21:\\\"messenger.bus.default\\\";}}s:57:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\TransportMessageIdStamp\\\";a:4:{i:0;O:57:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\TransportMessageIdStamp\\\":1:{s:61:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\TransportMessageIdStamp\\0id\\\";i:8;}i:1;O:57:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\TransportMessageIdStamp\\\":1:{s:61:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\TransportMessageIdStamp\\0id\\\";i:14;}i:2;O:57:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\TransportMessageIdStamp\\\":1:{s:61:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\TransportMessageIdStamp\\0id\\\";i:21;}i:3;O:57:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\TransportMessageIdStamp\\\":1:{s:61:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\TransportMessageIdStamp\\0id\\\";i:27;}}s:51:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\ErrorDetailsStamp\\\";a:1:{i:0;O:51:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\ErrorDetailsStamp\\\":4:{s:67:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\ErrorDetailsStamp\\0exceptionClass\\\";s:62:\\\"Symfony\\\\Component\\\\Mailer\\\\Exception\\\\UnexpectedResponseException\\\";s:66:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\ErrorDetailsStamp\\0exceptionCode\\\";i:550;s:69:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\ErrorDetailsStamp\\0exceptionMessage\\\";s:169:\\\"Expected response code \\\"354\\\" but got code \\\"550\\\", with message \\\"550 5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing\\\".\\\";s:69:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\ErrorDetailsStamp\\0flattenException\\\";O:57:\\\"Symfony\\\\Component\\\\ErrorHandler\\\\Exception\\\\FlattenException\\\":12:{s:66:\\\"\\0Symfony\\\\Component\\\\ErrorHandler\\\\Exception\\\\FlattenException\\0message\\\";s:169:\\\"Expected response code \\\"354\\\" but got code \\\"550\\\", with message \\\"550 5.7.0 Too many emails per second. Please upgrade your plan https://mailtrap.io/billing/plans/testing\\\".\\\";s:63:\\\"\\0Symfony\\\\Component\\\\ErrorHandler\\\\Exception\\\\FlattenException\\0code\\\";i:550;s:67:\\\"\\0Symfony\\\\Component\\\\ErrorHandler\\\\Exception\\\\FlattenException\\0previous\\\";N;s:64:\\\"\\0Symfony\\\\Component\\\\ErrorHandler\\\\Exception\\\\FlattenException\\0trace\\\";a:31:{i:0;a:8:{s:9:\\\"namespace\\\";s:0:\\\"\\\";s:11:\\\"short_class\\\";s:0:\\\"\\\";s:5:\\\"class\\\";s:0:\\\"\\\";s:4:\\\"type\\\";s:0:\\\"\\\";s:8:\\\"function\\\";s:0:\\\"\\\";s:4:\\\"file\\\";s:100:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php\\\";s:4:\\\"line\\\";i:342;s:4:\\\"args\\\";a:0:{}}i:1;a:8:{s:9:\\\"namespace\\\";s:39:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\";s:11:\\\"short_class\\\";s:13:\\\"SmtpTransport\\\";s:5:\\\"class\\\";s:53:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\\SmtpTransport\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:18:\\\"assertResponseCode\\\";s:4:\\\"file\\\";s:100:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php\\\";s:4:\\\"line\\\";i:198;s:4:\\\"args\\\";a:0:{}}i:2;a:8:{s:9:\\\"namespace\\\";s:39:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\";s:11:\\\"short_class\\\";s:13:\\\"SmtpTransport\\\";s:5:\\\"class\\\";s:53:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\\SmtpTransport\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:14:\\\"executeCommand\\\";s:4:\\\"file\\\";s:101:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/Smtp/EsmtpTransport.php\\\";s:4:\\\"line\\\";i:134;s:4:\\\"args\\\";a:0:{}}i:3;a:8:{s:9:\\\"namespace\\\";s:39:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\";s:11:\\\"short_class\\\";s:14:\\\"EsmtpTransport\\\";s:5:\\\"class\\\";s:54:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\\EsmtpTransport\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:14:\\\"executeCommand\\\";s:4:\\\"file\\\";s:100:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php\\\";s:4:\\\"line\\\";i:220;s:4:\\\"args\\\";a:0:{}}i:4;a:8:{s:9:\\\"namespace\\\";s:39:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\";s:11:\\\"short_class\\\";s:13:\\\"SmtpTransport\\\";s:5:\\\"class\\\";s:53:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\\SmtpTransport\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:6:\\\"doSend\\\";s:4:\\\"file\\\";s:99:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/AbstractTransport.php\\\";s:4:\\\"line\\\";i:90;s:4:\\\"args\\\";a:0:{}}i:5;a:8:{s:9:\\\"namespace\\\";s:34:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\";s:11:\\\"short_class\\\";s:17:\\\"AbstractTransport\\\";s:5:\\\"class\\\";s:52:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\\AbstractTransport\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:4:\\\"send\\\";s:4:\\\"file\\\";s:100:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php\\\";s:4:\\\"line\\\";i:138;s:4:\\\"args\\\";a:0:{}}i:6;a:8:{s:9:\\\"namespace\\\";s:39:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\";s:11:\\\"short_class\\\";s:13:\\\"SmtpTransport\\\";s:5:\\\"class\\\";s:53:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\\SmtpTransport\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:4:\\\"send\\\";s:4:\\\"file\\\";s:92:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/Transports.php\\\";s:4:\\\"line\\\";i:51;s:4:\\\"args\\\";a:0:{}}i:7;a:8:{s:9:\\\"namespace\\\";s:34:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\";s:11:\\\"short_class\\\";s:10:\\\"Transports\\\";s:5:\\\"class\\\";s:45:\\\"Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Transports\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:4:\\\"send\\\";s:4:\\\"file\\\";s:96:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Messenger/MessageHandler.php\\\";s:4:\\\"line\\\";i:29;s:4:\\\"args\\\";a:0:{}}i:8;a:8:{s:9:\\\"namespace\\\";s:34:\\\"Symfony\\\\Component\\\\Mailer\\\\Messenger\\\";s:11:\\\"short_class\\\";s:14:\\\"MessageHandler\\\";s:5:\\\"class\\\";s:49:\\\"Symfony\\\\Component\\\\Mailer\\\\Messenger\\\\MessageHandler\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:8:\\\"__invoke\\\";s:4:\\\"file\\\";s:109:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/HandleMessageMiddleware.php\\\";s:4:\\\"line\\\";i:152;s:4:\\\"args\\\";a:0:{}}i:9;a:8:{s:9:\\\"namespace\\\";s:38:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\";s:11:\\\"short_class\\\";s:23:\\\"HandleMessageMiddleware\\\";s:5:\\\"class\\\";s:62:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\HandleMessageMiddleware\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:11:\\\"callHandler\\\";s:4:\\\"file\\\";s:109:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/HandleMessageMiddleware.php\\\";s:4:\\\"line\\\";i:91;s:4:\\\"args\\\";a:0:{}}i:10;a:8:{s:9:\\\"namespace\\\";s:38:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\";s:11:\\\"short_class\\\";s:23:\\\"HandleMessageMiddleware\\\";s:5:\\\"class\\\";s:62:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\HandleMessageMiddleware\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:6:\\\"handle\\\";s:4:\\\"file\\\";s:107:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/SendMessageMiddleware.php\\\";s:4:\\\"line\\\";i:71;s:4:\\\"args\\\";a:0:{}}i:11;a:8:{s:9:\\\"namespace\\\";s:38:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\";s:11:\\\"short_class\\\";s:21:\\\"SendMessageMiddleware\\\";s:5:\\\"class\\\";s:60:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\SendMessageMiddleware\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:6:\\\"handle\\\";s:4:\\\"file\\\";s:119:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/FailedMessageProcessingMiddleware.php\\\";s:4:\\\"line\\\";i:34;s:4:\\\"args\\\";a:0:{}}i:12;a:8:{s:9:\\\"namespace\\\";s:38:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\";s:11:\\\"short_class\\\";s:33:\\\"FailedMessageProcessingMiddleware\\\";s:5:\\\"class\\\";s:72:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\FailedMessageProcessingMiddleware\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:6:\\\"handle\\\";s:4:\\\"file\\\";s:119:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/DispatchAfterCurrentBusMiddleware.php\\\";s:4:\\\"line\\\";i:68;s:4:\\\"args\\\";a:0:{}}i:13;a:8:{s:9:\\\"namespace\\\";s:38:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\";s:11:\\\"short_class\\\";s:33:\\\"DispatchAfterCurrentBusMiddleware\\\";s:5:\\\"class\\\";s:72:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\DispatchAfterCurrentBusMiddleware\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:6:\\\"handle\\\";s:4:\\\"file\\\";s:120:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/RejectRedeliveredMessageMiddleware.php\\\";s:4:\\\"line\\\";i:41;s:4:\\\"args\\\";a:0:{}}i:14;a:8:{s:9:\\\"namespace\\\";s:38:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\";s:11:\\\"short_class\\\";s:34:\\\"RejectRedeliveredMessageMiddleware\\\";s:5:\\\"class\\\";s:73:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\RejectRedeliveredMessageMiddleware\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:6:\\\"handle\\\";s:4:\\\"file\\\";s:111:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/AddBusNameStampMiddleware.php\\\";s:4:\\\"line\\\";i:35;s:4:\\\"args\\\";a:0:{}}i:15;a:8:{s:9:\\\"namespace\\\";s:38:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\";s:11:\\\"short_class\\\";s:25:\\\"AddBusNameStampMiddleware\\\";s:5:\\\"class\\\";s:64:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\AddBusNameStampMiddleware\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:6:\\\"handle\\\";s:4:\\\"file\\\";s:105:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/TraceableMiddleware.php\\\";s:4:\\\"line\\\";i:36;s:4:\\\"args\\\";a:0:{}}i:16;a:8:{s:9:\\\"namespace\\\";s:38:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\";s:11:\\\"short_class\\\";s:19:\\\"TraceableMiddleware\\\";s:5:\\\"class\\\";s:58:\\\"Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\TraceableMiddleware\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:6:\\\"handle\\\";s:4:\\\"file\\\";s:85:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/MessageBus.php\\\";s:4:\\\"line\\\";i:69;s:4:\\\"args\\\";a:0:{}}i:17;a:8:{s:9:\\\"namespace\\\";s:27:\\\"Symfony\\\\Component\\\\Messenger\\\";s:11:\\\"short_class\\\";s:10:\\\"MessageBus\\\";s:5:\\\"class\\\";s:38:\\\"Symfony\\\\Component\\\\Messenger\\\\MessageBus\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:8:\\\"dispatch\\\";s:4:\\\"file\\\";s:94:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/TraceableMessageBus.php\\\";s:4:\\\"line\\\";i:37;s:4:\\\"args\\\";a:0:{}}i:18;a:8:{s:9:\\\"namespace\\\";s:27:\\\"Symfony\\\\Component\\\\Messenger\\\";s:11:\\\"short_class\\\";s:19:\\\"TraceableMessageBus\\\";s:5:\\\"class\\\";s:47:\\\"Symfony\\\\Component\\\\Messenger\\\\TraceableMessageBus\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:8:\\\"dispatch\\\";s:4:\\\"file\\\";s:93:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/RoutableMessageBus.php\\\";s:4:\\\"line\\\";i:51;s:4:\\\"args\\\";a:0:{}}i:19;a:8:{s:9:\\\"namespace\\\";s:27:\\\"Symfony\\\\Component\\\\Messenger\\\";s:11:\\\"short_class\\\";s:18:\\\"RoutableMessageBus\\\";s:5:\\\"class\\\";s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\RoutableMessageBus\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:8:\\\"dispatch\\\";s:4:\\\"file\\\";s:81:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Worker.php\\\";s:4:\\\"line\\\";i:172;s:4:\\\"args\\\";a:0:{}}i:20;a:8:{s:9:\\\"namespace\\\";s:27:\\\"Symfony\\\\Component\\\\Messenger\\\";s:11:\\\"short_class\\\";s:6:\\\"Worker\\\";s:5:\\\"class\\\";s:34:\\\"Symfony\\\\Component\\\\Messenger\\\\Worker\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:13:\\\"handleMessage\\\";s:4:\\\"file\\\";s:81:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Worker.php\\\";s:4:\\\"line\\\";i:119;s:4:\\\"args\\\";a:0:{}}i:21;a:8:{s:9:\\\"namespace\\\";s:27:\\\"Symfony\\\\Component\\\\Messenger\\\";s:11:\\\"short_class\\\";s:6:\\\"Worker\\\";s:5:\\\"class\\\";s:34:\\\"Symfony\\\\Component\\\\Messenger\\\\Worker\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:3:\\\"run\\\";s:4:\\\"file\\\";s:105:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Command/ConsumeMessagesCommand.php\\\";s:4:\\\"line\\\";i:254;s:4:\\\"args\\\";a:0:{}}i:22;a:8:{s:9:\\\"namespace\\\";s:35:\\\"Symfony\\\\Component\\\\Messenger\\\\Command\\\";s:11:\\\"short_class\\\";s:22:\\\"ConsumeMessagesCommand\\\";s:5:\\\"class\\\";s:58:\\\"Symfony\\\\Component\\\\Messenger\\\\Command\\\\ConsumeMessagesCommand\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:7:\\\"execute\\\";s:4:\\\"file\\\";s:88:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/console/Command/Command.php\\\";s:4:\\\"line\\\";i:279;s:4:\\\"args\\\";a:0:{}}i:23;a:8:{s:9:\\\"namespace\\\";s:33:\\\"Symfony\\\\Component\\\\Console\\\\Command\\\";s:11:\\\"short_class\\\";s:7:\\\"Command\\\";s:5:\\\"class\\\";s:41:\\\"Symfony\\\\Component\\\\Console\\\\Command\\\\Command\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:3:\\\"run\\\";s:4:\\\"file\\\";s:84:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/console/Application.php\\\";s:4:\\\"line\\\";i:1094;s:4:\\\"args\\\";a:0:{}}i:24;a:8:{s:9:\\\"namespace\\\";s:25:\\\"Symfony\\\\Component\\\\Console\\\";s:11:\\\"short_class\\\";s:11:\\\"Application\\\";s:5:\\\"class\\\";s:37:\\\"Symfony\\\\Component\\\\Console\\\\Application\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:12:\\\"doRunCommand\\\";s:4:\\\"file\\\";s:101:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/framework-bundle/Console/Application.php\\\";s:4:\\\"line\\\";i:123;s:4:\\\"args\\\";a:0:{}}i:25;a:8:{s:9:\\\"namespace\\\";s:38:\\\"Symfony\\\\Bundle\\\\FrameworkBundle\\\\Console\\\";s:11:\\\"short_class\\\";s:11:\\\"Application\\\";s:5:\\\"class\\\";s:50:\\\"Symfony\\\\Bundle\\\\FrameworkBundle\\\\Console\\\\Application\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:12:\\\"doRunCommand\\\";s:4:\\\"file\\\";s:84:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/console/Application.php\\\";s:4:\\\"line\\\";i:342;s:4:\\\"args\\\";a:0:{}}i:26;a:8:{s:9:\\\"namespace\\\";s:25:\\\"Symfony\\\\Component\\\\Console\\\";s:11:\\\"short_class\\\";s:11:\\\"Application\\\";s:5:\\\"class\\\";s:37:\\\"Symfony\\\\Component\\\\Console\\\\Application\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:5:\\\"doRun\\\";s:4:\\\"file\\\";s:101:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/framework-bundle/Console/Application.php\\\";s:4:\\\"line\\\";i:77;s:4:\\\"args\\\";a:0:{}}i:27;a:8:{s:9:\\\"namespace\\\";s:38:\\\"Symfony\\\\Bundle\\\\FrameworkBundle\\\\Console\\\";s:11:\\\"short_class\\\";s:11:\\\"Application\\\";s:5:\\\"class\\\";s:50:\\\"Symfony\\\\Bundle\\\\FrameworkBundle\\\\Console\\\\Application\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:5:\\\"doRun\\\";s:4:\\\"file\\\";s:84:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/console/Application.php\\\";s:4:\\\"line\\\";i:193;s:4:\\\"args\\\";a:0:{}}i:28;a:8:{s:9:\\\"namespace\\\";s:25:\\\"Symfony\\\\Component\\\\Console\\\";s:11:\\\"short_class\\\";s:11:\\\"Application\\\";s:5:\\\"class\\\";s:37:\\\"Symfony\\\\Component\\\\Console\\\\Application\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:3:\\\"run\\\";s:4:\\\"file\\\";s:112:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/runtime/Runner/Symfony/ConsoleApplicationRunner.php\\\";s:4:\\\"line\\\";i:49;s:4:\\\"args\\\";a:0:{}}i:29;a:8:{s:9:\\\"namespace\\\";s:40:\\\"Symfony\\\\Component\\\\Runtime\\\\Runner\\\\Symfony\\\";s:11:\\\"short_class\\\";s:24:\\\"ConsoleApplicationRunner\\\";s:5:\\\"class\\\";s:65:\\\"Symfony\\\\Component\\\\Runtime\\\\Runner\\\\Symfony\\\\ConsoleApplicationRunner\\\";s:4:\\\"type\\\";s:2:\\\"->\\\";s:8:\\\"function\\\";s:3:\\\"run\\\";s:4:\\\"file\\\";s:73:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/autoload_runtime.php\\\";s:4:\\\"line\\\";i:29;s:4:\\\"args\\\";a:0:{}}i:30;a:8:{s:9:\\\"namespace\\\";s:0:\\\"\\\";s:11:\\\"short_class\\\";s:0:\\\"\\\";s:5:\\\"class\\\";s:0:\\\"\\\";s:4:\\\"type\\\";s:0:\\\"\\\";s:8:\\\"function\\\";s:12:\\\"require_once\\\";s:4:\\\"file\\\";s:57:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/bin/console\\\";s:4:\\\"line\\\";i:15;s:4:\\\"args\\\";a:1:{i:0;a:2:{i:0;s:6:\\\"string\\\";i:1;s:73:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/autoload_runtime.php\\\";}}}}s:72:\\\"\\0Symfony\\\\Component\\\\ErrorHandler\\\\Exception\\\\FlattenException\\0traceAsString\\\";s:5113:\\\"#0 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(198): Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\\SmtpTransport->assertResponseCode()\n#1 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/Smtp/EsmtpTransport.php(134): Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\\SmtpTransport->executeCommand()\n#2 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(220): Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\\EsmtpTransport->executeCommand()\n#3 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/AbstractTransport.php(90): Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\\SmtpTransport->doSend()\n#4 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php(138): Symfony\\\\Component\\\\Mailer\\\\Transport\\\\AbstractTransport->send()\n#5 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/Transports.php(51): Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Smtp\\\\SmtpTransport->send()\n#6 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Messenger/MessageHandler.php(29): Symfony\\\\Component\\\\Mailer\\\\Transport\\\\Transports->send()\n#7 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/HandleMessageMiddleware.php(152): Symfony\\\\Component\\\\Mailer\\\\Messenger\\\\MessageHandler->__invoke()\n#8 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/HandleMessageMiddleware.php(91): Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\HandleMessageMiddleware->callHandler()\n#9 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/SendMessageMiddleware.php(71): Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\HandleMessageMiddleware->handle()\n#10 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/FailedMessageProcessingMiddleware.php(34): Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\SendMessageMiddleware->handle()\n#11 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/DispatchAfterCurrentBusMiddleware.php(68): Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\FailedMessageProcessingMiddleware->handle()\n#12 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/RejectRedeliveredMessageMiddleware.php(41): Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\DispatchAfterCurrentBusMiddleware->handle()\n#13 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/AddBusNameStampMiddleware.php(35): Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\RejectRedeliveredMessageMiddleware->handle()\n#14 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Middleware/TraceableMiddleware.php(36): Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\AddBusNameStampMiddleware->handle()\n#15 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/MessageBus.php(69): Symfony\\\\Component\\\\Messenger\\\\Middleware\\\\TraceableMiddleware->handle()\n#16 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/TraceableMessageBus.php(37): Symfony\\\\Component\\\\Messenger\\\\MessageBus->dispatch()\n#17 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/RoutableMessageBus.php(51): Symfony\\\\Component\\\\Messenger\\\\TraceableMessageBus->dispatch()\n#18 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Worker.php(172): Symfony\\\\Component\\\\Messenger\\\\RoutableMessageBus->dispatch()\n#19 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Worker.php(119): Symfony\\\\Component\\\\Messenger\\\\Worker->handleMessage()\n#20 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/messenger/Command/ConsumeMessagesCommand.php(254): Symfony\\\\Component\\\\Messenger\\\\Worker->run()\n#21 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/console/Command/Command.php(279): Symfony\\\\Component\\\\Messenger\\\\Command\\\\ConsumeMessagesCommand->execute()\n#22 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/console/Application.php(1094): Symfony\\\\Component\\\\Console\\\\Command\\\\Command->run()\n#23 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/framework-bundle/Console/Application.php(123): Symfony\\\\Component\\\\Console\\\\Application->doRunCommand()\n#24 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/console/Application.php(342): Symfony\\\\Bundle\\\\FrameworkBundle\\\\Console\\\\Application->doRunCommand()\n#25 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/framework-bundle/Console/Application.php(77): Symfony\\\\Component\\\\Console\\\\Application->doRun()\n#26 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/console/Application.php(193): Symfony\\\\Bundle\\\\FrameworkBundle\\\\Console\\\\Application->doRun()\n#27 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/runtime/Runner/Symfony/ConsoleApplicationRunner.php(49): Symfony\\\\Component\\\\Console\\\\Application->run()\n#28 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/autoload_runtime.php(29): Symfony\\\\Component\\\\Runtime\\\\Runner\\\\Symfony\\\\ConsoleApplicationRunner->run()\n#29 /home/orcryx/Bureau/OpenClassRooms/SnowTricks/bin/console(15): require_once(\\\'...\\\')\n#30 {main}\\\";s:64:\\\"\\0Symfony\\\\Component\\\\ErrorHandler\\\\Exception\\\\FlattenException\\0class\\\";s:62:\\\"Symfony\\\\Component\\\\Mailer\\\\Exception\\\\UnexpectedResponseException\\\";s:69:\\\"\\0Symfony\\\\Component\\\\ErrorHandler\\\\Exception\\\\FlattenException\\0statusCode\\\";i:500;s:69:\\\"\\0Symfony\\\\Component\\\\ErrorHandler\\\\Exception\\\\FlattenException\\0statusText\\\";s:21:\\\"Internal Server Error\\\";s:66:\\\"\\0Symfony\\\\Component\\\\ErrorHandler\\\\Exception\\\\FlattenException\\0headers\\\";a:0:{}s:63:\\\"\\0Symfony\\\\Component\\\\ErrorHandler\\\\Exception\\\\FlattenException\\0file\\\";s:100:\\\"/home/orcryx/Bureau/OpenClassRooms/SnowTricks/vendor/symfony/mailer/Transport/Smtp/SmtpTransport.php\\\";s:63:\\\"\\0Symfony\\\\Component\\\\ErrorHandler\\\\Exception\\\\FlattenException\\0line\\\";i:342;s:67:\\\"\\0Symfony\\\\Component\\\\ErrorHandler\\\\Exception\\\\FlattenException\\0asString\\\";N;}}}s:44:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\DelayStamp\\\";a:4:{i:0;O:44:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\DelayStamp\\\":1:{s:51:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\DelayStamp\\0delay\\\";i:1083;}i:1;O:44:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\DelayStamp\\\":1:{s:51:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\DelayStamp\\0delay\\\";i:1988;}i:2;O:44:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\DelayStamp\\\":1:{s:51:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\DelayStamp\\0delay\\\";i:3969;}i:3;O:44:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\DelayStamp\\\":1:{s:51:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\DelayStamp\\0delay\\\";i:0;}}s:49:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\RedeliveryStamp\\\";a:4:{i:0;O:49:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\RedeliveryStamp\\\":2:{s:64:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\RedeliveryStamp\\0redeliveredAt\\\";O:17:\\\"DateTimeImmutable\\\":3:{s:4:\\\"date\\\";s:26:\\\"2025-01-07 10:54:03.023221\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:3:\\\"UTC\\\";}s:61:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\RedeliveryStamp\\0retryCount\\\";i:1;}i:1;O:49:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\RedeliveryStamp\\\":2:{s:64:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\RedeliveryStamp\\0redeliveredAt\\\";O:17:\\\"DateTimeImmutable\\\":3:{s:4:\\\"date\\\";s:26:\\\"2025-01-07 10:54:06.379949\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:3:\\\"UTC\\\";}s:61:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\RedeliveryStamp\\0retryCount\\\";i:2;}i:2;O:49:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\RedeliveryStamp\\\":2:{s:64:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\RedeliveryStamp\\0redeliveredAt\\\";O:17:\\\"DateTimeImmutable\\\":3:{s:4:\\\"date\\\";s:26:\\\"2025-01-07 10:54:09.254044\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:3:\\\"UTC\\\";}s:61:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\RedeliveryStamp\\0retryCount\\\";i:3;}i:3;O:49:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\RedeliveryStamp\\\":2:{s:64:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\RedeliveryStamp\\0redeliveredAt\\\";O:17:\\\"DateTimeImmutable\\\":3:{s:4:\\\"date\\\";s:26:\\\"2025-01-07 10:54:13.288291\\\";s:13:\\\"timezone_type\\\";i:3;s:8:\\\"timezone\\\";s:3:\\\"UTC\\\";}s:61:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\RedeliveryStamp\\0retryCount\\\";i:0;}}s:61:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\SentToFailureTransportStamp\\\";a:1:{i:0;O:61:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\SentToFailureTransportStamp\\\":1:{s:83:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\SentToFailureTransportStamp\\0originalReceiverName\\\";s:5:\\\"async\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:51:\\\"Symfony\\\\Component\\\\Mailer\\\\Messenger\\\\SendEmailMessage\\\":2:{s:60:\\\"\\0Symfony\\\\Component\\\\Mailer\\\\Messenger\\\\SendEmailMessage\\0message\\\";O:39:\\\"Symfony\\\\Bridge\\\\Twig\\\\Mime\\\\TemplatedEmail\\\":5:{i:0;s:41:\\\"registration/confirmation_email.html.twig\\\";i:1;N;i:2;a:3:{s:9:\\\"signedUrl\\\";s:171:\\\"http://127.0.0.1:8000/verify/email?expires=1736248517&signature=zo726qv95ApDKsBllWSSmrh%2FhHmR2mS15UXVNb%2FZr2I%3D&token=bX6SKlsAJFZLomO9l4Xf%2Fwc8WRvB4sZmw%2Fbk7vLAGEc%3D\\\";s:19:\\\"expiresAtMessageKey\\\";s:26:\\\"%count% hour|%count% hours\\\";s:20:\\\"expiresAtMessageData\\\";a:1:{s:7:\\\"%count%\\\";i:1;}}i:3;a:6:{i:0;N;i:1;N;i:2;N;i:3;N;i:4;a:0:{}i:5;a:2:{i:0;O:37:\\\"Symfony\\\\Component\\\\Mime\\\\Header\\\\Headers\\\":2:{s:46:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\Headers\\0headers\\\";a:3:{s:4:\\\"from\\\";a:1:{i:0;O:47:\\\"Symfony\\\\Component\\\\Mime\\\\Header\\\\MailboxListHeader\\\":5:{s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0name\\\";s:4:\\\"From\\\";s:56:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lineLength\\\";i:76;s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lang\\\";N;s:53:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0charset\\\";s:5:\\\"utf-8\\\";s:58:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\MailboxListHeader\\0addresses\\\";a:1:{i:0;O:30:\\\"Symfony\\\\Component\\\\Mime\\\\Address\\\":2:{s:39:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Address\\0address\\\";s:21:\\\"lauryanndev@gmail.com\\\";s:36:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Address\\0name\\\";s:7:\\\"Support\\\";}}}}s:2:\\\"to\\\";a:1:{i:0;O:47:\\\"Symfony\\\\Component\\\\Mime\\\\Header\\\\MailboxListHeader\\\":5:{s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0name\\\";s:2:\\\"To\\\";s:56:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lineLength\\\";i:76;s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lang\\\";N;s:53:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0charset\\\";s:5:\\\"utf-8\\\";s:58:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\MailboxListHeader\\0addresses\\\";a:1:{i:0;O:30:\\\"Symfony\\\\Component\\\\Mime\\\\Address\\\":2:{s:39:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Address\\0address\\\";s:13:\\\"lame@mail.com\\\";s:36:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Address\\0name\\\";s:0:\\\"\\\";}}}}s:7:\\\"subject\\\";a:1:{i:0;O:48:\\\"Symfony\\\\Component\\\\Mime\\\\Header\\\\UnstructuredHeader\\\":5:{s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0name\\\";s:7:\\\"Subject\\\";s:56:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lineLength\\\";i:76;s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lang\\\";N;s:53:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0charset\\\";s:5:\\\"utf-8\\\";s:55:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\UnstructuredHeader\\0value\\\";s:31:\\\"Merci de confirmer votre email.\\\";}}}s:49:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\Headers\\0lineLength\\\";i:76;}i:1;N;}}i:4;N;}s:61:\\\"\\0Symfony\\\\Component\\\\Mailer\\\\Messenger\\\\SendEmailMessage\\0envelope\\\";N;}}','[]','failed','2025-01-07 10:54:13','2025-01-07 10:54:13',NULL),
(29,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:21:\\\"messenger.bus.default\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:51:\\\"Symfony\\\\Component\\\\Mailer\\\\Messenger\\\\SendEmailMessage\\\":2:{s:60:\\\"\\0Symfony\\\\Component\\\\Mailer\\\\Messenger\\\\SendEmailMessage\\0message\\\";O:39:\\\"Symfony\\\\Bridge\\\\Twig\\\\Mime\\\\TemplatedEmail\\\":5:{i:0;s:41:\\\"registration/confirmation_email.html.twig\\\";i:1;N;i:2;a:3:{s:9:\\\"signedUrl\\\";s:169:\\\"http://127.0.0.1:8000/verify/email?expires=1736251151&signature=iinxwpvmb3xc%2BJKMF7xcMgZR3IQc9CA3QXu2icZRAmw%3D&token=AmZVnAitm6BnaerKMDt%2FYpyrBBxXpL3XWE8LAC5%2FPLI%3D\\\";s:19:\\\"expiresAtMessageKey\\\";s:26:\\\"%count% hour|%count% hours\\\";s:20:\\\"expiresAtMessageData\\\";a:1:{s:7:\\\"%count%\\\";i:1;}}i:3;a:6:{i:0;N;i:1;N;i:2;N;i:3;N;i:4;a:0:{}i:5;a:2:{i:0;O:37:\\\"Symfony\\\\Component\\\\Mime\\\\Header\\\\Headers\\\":2:{s:46:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\Headers\\0headers\\\";a:3:{s:4:\\\"from\\\";a:1:{i:0;O:47:\\\"Symfony\\\\Component\\\\Mime\\\\Header\\\\MailboxListHeader\\\":5:{s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0name\\\";s:4:\\\"From\\\";s:56:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lineLength\\\";i:76;s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lang\\\";N;s:53:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0charset\\\";s:5:\\\"utf-8\\\";s:58:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\MailboxListHeader\\0addresses\\\";a:1:{i:0;O:30:\\\"Symfony\\\\Component\\\\Mime\\\\Address\\\":2:{s:39:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Address\\0address\\\";s:21:\\\"lauryanndev@gmail.com\\\";s:36:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Address\\0name\\\";s:7:\\\"Support\\\";}}}}s:2:\\\"to\\\";a:1:{i:0;O:47:\\\"Symfony\\\\Component\\\\Mime\\\\Header\\\\MailboxListHeader\\\":5:{s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0name\\\";s:2:\\\"To\\\";s:56:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lineLength\\\";i:76;s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lang\\\";N;s:53:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0charset\\\";s:5:\\\"utf-8\\\";s:58:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\MailboxListHeader\\0addresses\\\";a:1:{i:0;O:30:\\\"Symfony\\\\Component\\\\Mime\\\\Address\\\":2:{s:39:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Address\\0address\\\";s:21:\\\"noel@papanoelmail.com\\\";s:36:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Address\\0name\\\";s:0:\\\"\\\";}}}}s:7:\\\"subject\\\";a:1:{i:0;O:48:\\\"Symfony\\\\Component\\\\Mime\\\\Header\\\\UnstructuredHeader\\\":5:{s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0name\\\";s:7:\\\"Subject\\\";s:56:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lineLength\\\";i:76;s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lang\\\";N;s:53:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0charset\\\";s:5:\\\"utf-8\\\";s:55:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\UnstructuredHeader\\0value\\\";s:31:\\\"Merci de confirmer votre email.\\\";}}}s:49:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\Headers\\0lineLength\\\";i:76;}i:1;N;}}i:4;N;}s:61:\\\"\\0Symfony\\\\Component\\\\Mailer\\\\Messenger\\\\SendEmailMessage\\0envelope\\\";N;}}','[]','default','2025-01-07 10:59:11','2025-01-07 10:59:11',NULL),
(30,'O:36:\\\"Symfony\\\\Component\\\\Messenger\\\\Envelope\\\":2:{s:44:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0stamps\\\";a:1:{s:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\";a:1:{i:0;O:46:\\\"Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\\":1:{s:55:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Stamp\\\\BusNameStamp\\0busName\\\";s:21:\\\"messenger.bus.default\\\";}}}s:45:\\\"\\0Symfony\\\\Component\\\\Messenger\\\\Envelope\\0message\\\";O:51:\\\"Symfony\\\\Component\\\\Mailer\\\\Messenger\\\\SendEmailMessage\\\":2:{s:60:\\\"\\0Symfony\\\\Component\\\\Mailer\\\\Messenger\\\\SendEmailMessage\\0message\\\";O:39:\\\"Symfony\\\\Bridge\\\\Twig\\\\Mime\\\\TemplatedEmail\\\":5:{i:0;s:41:\\\"registration/confirmation_email.html.twig\\\";i:1;N;i:2;a:3:{s:9:\\\"signedUrl\\\";s:167:\\\"http://127.0.0.1:8000/verify/email?expires=1736251238&signature=jPF%2FS52xUdTkFPZqJWG0pYC5cpqpTGMD27w31f4swf8%3D&token=inwxT5ojKcF9wInekTkvhy2XQ4MAgJ21nULe2ZRZ%2BPI%3D\\\";s:19:\\\"expiresAtMessageKey\\\";s:26:\\\"%count% hour|%count% hours\\\";s:20:\\\"expiresAtMessageData\\\";a:1:{s:7:\\\"%count%\\\";i:1;}}i:3;a:6:{i:0;N;i:1;N;i:2;N;i:3;N;i:4;a:0:{}i:5;a:2:{i:0;O:37:\\\"Symfony\\\\Component\\\\Mime\\\\Header\\\\Headers\\\":2:{s:46:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\Headers\\0headers\\\";a:3:{s:4:\\\"from\\\";a:1:{i:0;O:47:\\\"Symfony\\\\Component\\\\Mime\\\\Header\\\\MailboxListHeader\\\":5:{s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0name\\\";s:4:\\\"From\\\";s:56:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lineLength\\\";i:76;s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lang\\\";N;s:53:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0charset\\\";s:5:\\\"utf-8\\\";s:58:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\MailboxListHeader\\0addresses\\\";a:1:{i:0;O:30:\\\"Symfony\\\\Component\\\\Mime\\\\Address\\\":2:{s:39:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Address\\0address\\\";s:21:\\\"lauryanndev@gmail.com\\\";s:36:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Address\\0name\\\";s:7:\\\"Support\\\";}}}}s:2:\\\"to\\\";a:1:{i:0;O:47:\\\"Symfony\\\\Component\\\\Mime\\\\Header\\\\MailboxListHeader\\\":5:{s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0name\\\";s:2:\\\"To\\\";s:56:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lineLength\\\";i:76;s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lang\\\";N;s:53:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0charset\\\";s:5:\\\"utf-8\\\";s:58:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\MailboxListHeader\\0addresses\\\";a:1:{i:0;O:30:\\\"Symfony\\\\Component\\\\Mime\\\\Address\\\":2:{s:39:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Address\\0address\\\";s:21:\\\"noel@papanoelmail.com\\\";s:36:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Address\\0name\\\";s:0:\\\"\\\";}}}}s:7:\\\"subject\\\";a:1:{i:0;O:48:\\\"Symfony\\\\Component\\\\Mime\\\\Header\\\\UnstructuredHeader\\\":5:{s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0name\\\";s:7:\\\"Subject\\\";s:56:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lineLength\\\";i:76;s:50:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0lang\\\";N;s:53:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\AbstractHeader\\0charset\\\";s:5:\\\"utf-8\\\";s:55:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\UnstructuredHeader\\0value\\\";s:31:\\\"Merci de confirmer votre email.\\\";}}}s:49:\\\"\\0Symfony\\\\Component\\\\Mime\\\\Header\\\\Headers\\0lineLength\\\";i:76;}i:1;N;}}i:4;N;}s:61:\\\"\\0Symfony\\\\Component\\\\Mailer\\\\Messenger\\\\SendEmailMessage\\0envelope\\\";N;}}','[]','default','2025-01-07 11:00:38','2025-01-07 11:00:38',NULL);
/*!40000 ALTER TABLE `messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `picture`
--

DROP TABLE IF EXISTS `picture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `picture` (
  `id` int NOT NULL AUTO_INCREMENT,
  `trick_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `src` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_at` datetime NOT NULL,
  `update_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_16DB4F89B281BE2E` (`trick_id`),
  CONSTRAINT `FK_16DB4F89B281BE2E` FOREIGN KEY (`trick_id`) REFERENCES `trick` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `picture`
--

LOCK TABLES `picture` WRITE;
/*!40000 ALTER TABLE `picture` DISABLE KEYS */;
INSERT INTO `picture` VALUES
(29,39,'default','https://contents.mediadecathlon.com/p2296527/k$d723d2841cdaf4f9687839dd9b9cb8a4/1920x0/1863pt2795/3726xcr2795/Comment-faire-un-50-50-en-snowboard-.jpg?format=auto','2025-02-05 14:40:26','2025-03-05 13:08:06'),
(34,45,'Jamie Anderson  big air event','https://static01.nyt.com/images/2018/02/06/sports/bigair-explainer-web/bigair-explainer-web-jumbo.jpg?quality=75&auto=webp','2025-02-21 16:40:28','2025-03-05 11:05:40'),
(35,42,'default','https://www.snowboarder.com/.image/c_limit%2Ccs_srgb%2Cq_auto:eco%2Cw_700/MTk2MzUwNjg0MjE2MzcwODM0/ingemar-backman-massive-backside-air-transworld.webp','2025-02-23 10:22:39','2025-03-05 12:55:25'),
(42,45,'McMorris big air','https://swiftmedia.s3.amazonaws.com/mountain.swiftcom.com/images/sites/5/2022/08/10221010/dba3980f-374e-571f-b2e4-dc5aa857e69e-scaled.jpg','2025-03-05 11:05:40','2025-03-05 11:05:40'),
(43,46,'image','https://cdn.shopify.com/s/files/1/2059/8303/files/FeatCollection2-SnowShop_SP.jpg?v=1583945522','2025-03-05 11:12:45','2025-03-05 11:12:45'),
(44,41,'default','https://snowboardaddiction.com/cdn/shop/articles/How_to_Ride_Switch_900x.jpg?v=1548897095','2025-03-05 13:01:43','2025-03-05 13:01:43'),
(45,41,'etape du switch','https://www.burton.com/static/community/advice/snowboard-tricks-to-learn-now-switch-3.jpg','2025-03-05 13:01:43','2025-03-05 13:01:43'),
(46,49,'gif 270','https://cdn.shopify.com/s/files/1/0230/2239/files/Webp.net-gifmaker_66ade9bb-7f2a-4d45-84e3-0c36d2205273_2048x2048.gif?v=1495401674','2025-03-05 13:19:56','2025-03-05 13:20:30'),
(47,49,'rotation 270','https://cdn.shopify.com/s/files/1/0230/2239/files/Webp.net-gifmaker_d28aeb77-031d-4580-81d0-ff784f7aa7c4_1024x1024.gif?v=1495402755','2025-03-05 13:20:30','2025-03-05 13:20:30'),
(48,50,'default','https://snowboardaddiction.com/cdn/shop/articles/How_To_Nollie_900x.jpg?v=1558804723','2025-03-05 13:25:33','2025-03-05 13:25:33'),
(49,52,'default','https://i.ytimg.com/vi/JDkqX2Ny3pE/maxresdefault.jpg','2025-03-05 13:38:33','2025-03-05 13:38:33'),
(50,52,'George Pappas','https://i.pinimg.com/736x/2b/c2/5c/2bc25c889d2e1845b05dc3e894eef529.jpg','2025-03-05 13:38:33','2025-03-05 13:38:33');
/*!40000 ALTER TABLE `picture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reset_password_request`
--

DROP TABLE IF EXISTS `reset_password_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `reset_password_request` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `selector` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hashed_token` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `requested_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `expires_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  PRIMARY KEY (`id`),
  KEY `IDX_7CE748AA76ED395` (`user_id`),
  CONSTRAINT `FK_7CE748AA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reset_password_request`
--

LOCK TABLES `reset_password_request` WRITE;
/*!40000 ALTER TABLE `reset_password_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `reset_password_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `token`
--

DROP TABLE IF EXISTS `token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `token` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5F37A13BA76ED395` (`user_id`),
  CONSTRAINT `FK_5F37A13BA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `token`
--

LOCK TABLES `token` WRITE;
/*!40000 ALTER TABLE `token` DISABLE KEYS */;
/*!40000 ALTER TABLE `token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trick`
--

DROP TABLE IF EXISTS `trick`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `trick` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `create_at` datetime NOT NULL,
  `update_at` datetime NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_D8F0A91E5E237E06` (`name`),
  UNIQUE KEY `UNIQ_D8F0A91E989D9B62` (`slug`),
  KEY `IDX_D8F0A91E12469DE2` (`category_id`),
  KEY `IDX_D8F0A91EA76ED395` (`user_id`),
  CONSTRAINT `FK_D8F0A91E12469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  CONSTRAINT `FK_D8F0A91EA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trick`
--

LOCK TABLES `trick` WRITE;
/*!40000 ALTER TABLE `trick` DISABLE KEYS */;
INSERT INTO `trick` VALUES
(38,7,'HANDPLANT','Un trick inspiré du skate qui consiste à tenir en équilibre sur une ou deux mains au sommet d\'une courbe. Existe avec de nombreuses variantes dans les grabs et les rotations.','2025-02-05 14:40:04','2025-03-05 13:11:20','handplant',16,'https://i.ibb.co/gg1tB3H/mute-Default.jpg'),
(39,6,'BOARDSLIDE 50-50','Commencez par rouler vers la boîte. Faites quelques contrôles de vitesse, si nécessaire, pour ajuster votre vitesse. Il peut prendre quelques essais avant que vous sachiez exactement combien de vitesse vous avez besoin, mais une règle générale est d\'aller un peu plus vite que vous ne pensez que vous ne devriez. La vitesse vous aidera à surmonter la boîte et à vous désintégrer si vous perdez votre équilibre.','2025-02-05 14:40:26','2025-03-05 13:08:06','boardslide-50-50',16,'https://i.ibb.co/gg1tB3H/mute-Default.jpg'),
(41,6,'Switch','Lorsque l\'on ride de son mauvais côté, tous les noms de figures sont précédées de la dénomination switch. Un regular fera donc ses tricks en switch, comme un goofie, et inversement.','2025-02-18 14:20:51','2025-03-05 13:01:43','switch',16,'https://snowboardaddiction.com/cdn/shop/articles/How_to_Ride_Switch_900x.jpg?v=1548897095'),
(42,1,'Backside Air','Le grab star du snowboard qui peut être fait d\'autant de façon différentes qu\'il y a de styles de riders. Il consiste à attraper la carre arrière entre les pieds, ou légèrement devant, et à pousser avec sa jambe arrière pour ramener la planche devant.','2025-02-18 15:07:55','2025-03-05 12:55:25','backside-air',16,'https://www.snowsurf.com/media/Cody%20Rosenthal.png'),
(45,4,'Big Air','Le déroulement d\'un saut est le suivant :\n\n    - le rider prend la vitesse qu\'il juge nécessaire sur la piste d\'élan ;\n    - il déclenche son saut lorsqu\'il arrive à l\'extrémité du kick ;\n    - il effectue sa figure en l\'air en passant par-dessus la table ;\n    - enfin, il atterrit en douceur sur la récep. Ses vitesses verticale et horizontale sont suffisantes pour que sa trajectoire épouse correctement la pente de la récep, de façon à atterrir sans choc, même après une chute de plusieurs mètres. Le rider évolue avec ou sans ses bâtons.','2025-02-21 16:40:28','2025-03-05 11:05:40','big-air',16,'https://media.wired.com/photos/5a6a74eb3766960ab49fc4cd/master/w_2560%2Cc_limit/0218-WI-APCORK-web.jpg'),
(46,1,'mute','Vous devez saisir avec la main avant sur le côté talon de votre planche, mais la différence réside dans la technique. Contrairement au Melon où vous devez plier les genoux et tendre la main pour attraper la planche, la méthode nécessite une extension des jambes pour que la planche et vos mains puissent se rencontrer à mi-chemin.\n\nUne fois en l\'air, levez vos jambes derrière vous jusqu\'à ce que votre planche soit parallèle à votre dos, puis attrapez le bord côté talon de votre planche entre les fixations avec votre main avant. Essayez de tenir le grab le plus longtemps possible pour plus de style. Une fois la méthode maîtrisée, n\'hésitez pas à pousser votre pied arrière vers l\'extérieur pour ajouter un tweak savoureux à votre nouveau trick.','2025-02-24 14:13:28','2025-03-05 11:12:45','mute',16,'https://cdn.shopify.com/s/files/1/2059/8303/files/5-snowboard-grabs-you-can-learn-in-one-day-9.jpg?v=1663119258'),
(49,2,'Rotation 270','Désigne le degré de rotation, soit 3/4 de tour, fait en entrée ou en sortie sur un jib. Certains riders font également des rotations en 450 degrés avant ou après les jibs.','2025-03-05 13:19:56','2025-03-05 13:20:30','rotation-270',16,'https://snowboardaddiction.com/cdn/shop/articles/Cover_900x.jpg?v=1495398627'),
(50,4,'Nollie','Ollies are one of the most essential skills to learn when it comes to Snowboarding. Whether you\'re hitting park jumps, side hits, urban jib features or freeriding, the ollie is the most efficient way of getting air. Get this skill on lock down and take your riding to new heights!','2025-03-05 13:25:33','2025-03-05 13:25:33','nollie',16,'https://snowboardaddiction.com/cdn/shop/articles/How_To_Nollie_900x.jpg?v=1558804723'),
(51,6,'Revert','Désigne un mouvement où le snowboarder effectue une rotation pour revenir à sa position de départ après avoir exécuté un trick ou une manœuvre. Par exemple, si un snowboarder fait un 180 (demi-tour) en l\'air et atterrit en switch (position opposée à la normale), il peut ensuite faire un revert pour revenir à sa position régulière sans sauter à nouveau. Ce mouvement est souvent utilisé pour maintenir la fluidité et le style dans une série de figures ou pour préparer la prochaine manœuvre.','2025-03-05 13:31:53','2025-03-05 13:31:53','revert',16,'https://snowtricks.florianjourde.com/uploads/tricks/63c142064da91.jpg'),
(52,4,'Crippler','Une autre rotation tête en bas classique qui s\'apparente à un backflip sur un mur frontside de pipe ou un quarter.','2025-03-05 13:38:33','2025-03-05 13:38:33','crippler',5,'https://live.staticflickr.com/8619/16710294476_e0877646b0_b.jpg');
/*!40000 ALTER TABLE `trick` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `pseudo` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_at` datetime NOT NULL,
  `update_at` datetime NOT NULL,
  `is_verified` tinyint(1) NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_IDENTIFIER_EMAIL` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES
(5,'$2y$13$7OwiDg38wcgiFhu1NvAojOO4Aml1KIClwjQ7TD3A8t/CtXCc8Uyse','lauryanndev@gmail.com','[\"USER_ADMIN\"]','AdminLame','2024-12-18 15:10:31','2024-12-18 15:10:31',1,'https://cdn.pixabay.com/photo/2024/07/23/13/03/moon-8915307_960_720.png'),
(16,'$2y$13$zjc.pgwbADY7DINehfhQAODu6BeL2QICoGtUAi0y.S2W6XpQrYtra','lame@mail.com','[]','lame','2025-01-07 10:56:58','2025-01-07 10:56:58',1,'https://img.freepik.com/free-vector/para-snowboardconcept-illustration_114360-18352.jpg?t=st=1739357464~exp=1739361064~hmac=3c44f0af1d6e4b522e2dff3f44b22d5d5b8919032b5f8ab1dabe300c71267b80&w=740'),
(19,'$2y$13$OC2g3NeQYm9.aKGr3MBBjuxMPKeAZ9tgDg95l4P22sXNUSc4nbbde','fdg@mail.com','[]','MasterTrick','2025-01-07 11:04:15','2025-01-07 11:04:15',1,'https://img.freepik.com/free-vector/para-snowboard-concept-illustration_114360-18652.jpg?t=st=1739357468~exp=1739361068~hmac=a07bc3226f1e32633ef2709e2ac8247ecf22dc927e3f7228b01f0fb0d32911d7&w=740'),
(20,'$2y$13$wMF5SSk2SSUGXACtKLcgdOos1XZLFQu8nIpabtDXGkwBRVpbOKLge','testeur@mail.com','[]','Supertesteur','2025-01-08 15:52:20','2025-01-08 15:52:20',1,'https://img.freepik.com/free-vector/para-snowboardconcept-illustration_114360-18352.jpg?t=st=1739357464~exp=1739361064~hmac=3c44f0af1d6e4b522e2dff3f44b22d5d5b8919032b5f8ab1dabe300c71267b80&w=740'),
(25,'$2y$13$LQiNLcZFbkQwiEOY27tUFukh98ajikQelhV7.Yd.tyI7uqJr5AGRe','testeur2602@mail.com','[]','jonDoe','2025-03-05 13:48:21','2025-03-05 13:48:21',1,'https://img.freepik.com/free-vector/para-snowboardconcept-illustration_114360-18352.jpg?t=st=1739357464~exp=1739361064~hmac=3c44f0af1d6e4b522e2dff3f44b22d5d5b8919032b5f8ab1dabe300c71267b80&w=740');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `video` (
  `id` int NOT NULL AUTO_INCREMENT,
  `trick_id` int NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `src` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `create_at` datetime NOT NULL,
  `update_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_7CC7DA2CB281BE2E` (`trick_id`),
  CONSTRAINT `FK_7CC7DA2CB281BE2E` FOREIGN KEY (`trick_id`) REFERENCES `trick` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video`
--

LOCK TABLES `video` WRITE;
/*!40000 ALTER TABLE `video` DISABLE KEYS */;
INSERT INTO `video` VALUES
(7,42,'Snowboard tuto Le Back Side Air','https://youtu.be/vf_st7mh0ag?si=c_w-DVGrkJa4SWIc','2025-02-23 10:30:42','2025-03-05 12:55:25'),
(11,45,'HIGHLIGHTS  X Games Aspen 2022','https://youtu.be/xIgDzNiI1x8?si=sj1KgKjwBmXFujHV','2025-03-05 11:05:40','2025-03-05 11:05:40'),
(12,46,'How to Mute Grab on a Snowboard','https://youtu.be/jm19nEvmZgM?si=m5osFb19KM1-TAhb','2025-03-05 11:12:45','2025-03-05 11:12:45'),
(13,41,'Comment faire du Switch sur piste','https://youtu.be/OYDDChgbDyQ?si=PDxPmY-yhTGprYYq','2025-03-05 12:58:23','2025-03-05 13:01:43'),
(14,39,'Comment faire un 50 50','https://youtu.be/Bj3EmTrlEbw?si=dZfu3yNSpODUG60X','2025-03-05 13:04:27','2025-03-05 13:08:06'),
(15,38,'HOW TO HANDPLANT','https://youtu.be/us8tZcQ1GrY?si=rfd7DU8JpJ0m78w1','2025-03-05 13:11:20','2025-03-05 13:11:20'),
(16,38,'Apprendre a faire un handplant backside','https://youtu.be/kkEqGPrh2yU?si=0sXio20Y9Z5o8EIi','2025-03-05 13:11:20','2025-03-05 13:11:20'),
(17,49,'How To 270 Out On A Snowboard','https://youtu.be/HM2IPsak2-E?si=f7lkROFxDX4EKQZv','2025-03-05 13:19:56','2025-03-05 13:20:30'),
(18,50,'How To Nollie On A Snowboard','https://youtu.be/aAzP3wNT220?si=_Rs7mVJbUlwJhCD6','2025-03-05 13:25:33','2025-03-05 13:25:33'),
(19,51,'Snowboard REVERT CARVE tutorial','https://youtu.be/gQ0x8oUKbrE?si=KXPce-Us4MseB0jl','2025-03-05 13:31:53','2025-03-05 13:31:53'),
(20,51,'HOW TO DO A BACKSIDE REVERT','https://youtu.be/p5UD3_ohf1s?si=ZjQaM9tL1qZ_GOCU','2025-03-05 13:31:53','2025-03-05 13:31:53'),
(21,52,'Crippler in a Half-Pipe with Iouri Podladtchikov','https://youtu.be/JDkqX2Ny3pE?si=_swqFwzJoxUvkt0u','2025-03-05 13:38:33','2025-03-05 13:38:33');
/*!40000 ALTER TABLE `video` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'SnowTricks'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-03-05 15:43:56
